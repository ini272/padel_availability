from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from app.core.database import get_db
from app.models.models import CrewMember
from app.schemas.schemas import CrewMemberCreate, CrewMember as CrewMemberSchema
from app.crud.crud import get_all, get_by_id, create_item, update_item, delete_item

router = APIRouter()

@router.get("/", response_model=List[CrewMemberSchema])
def read_crew_members(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    return get_all(CrewMember, skip, limit, db)

@router.post("/", response_model=CrewMemberSchema)
def create_crew_member(crew_member: CrewMemberCreate, db: Session = Depends(get_db)):
    return create_item(CrewMember, crew_member, db)

@router.get("/{crew_member_id}", response_model=CrewMemberSchema)
def read_crew_member(crew_member_id: int, db: Session = Depends(get_db)):
    return get_by_id(CrewMember, crew_member_id, db)

@router.put("/{crew_member_id}", response_model=CrewMemberSchema)
def update_crew_member(crew_member_id: int, crew_member: CrewMemberCreate, db: Session = Depends(get_db)):
    return update_item(CrewMember, crew_member_id, crew_member, db)

@router.delete("/{crew_member_id}", response_model=CrewMemberSchema)
def delete_crew_member(crew_member_id: int, db: Session = Depends(get_db)):
    return delete_item(CrewMember, crew_member_id, db)