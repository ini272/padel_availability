from fastapi.testclient import TestClient
from app.main import app
from app.core.enums import Role

client = TestClient(app)

def test_create_crew_member():
    response = client.post(
        "/crew/",
        json={
            "name": "John Doe",
            "role": Role.CREW
        }
    )
    assert response.status_code == 200
    assert response.json()["name"] == "John Doe"

def test_update_crew_member():
    # Create crew member first
    create_response = client.post(
        "/crew/",
        json={
            "name": "Jane Doe",
            "role": Role.CREW
        }
    )
    crew_id = create_response.json()["id"]
    
    # Update to coordinator
    update_response = client.put(
        f"/crew/{crew_id}",
        json={
            "name": "Jane Smith",
            "role": Role.COORDINATOR
        }
    )
    assert update_response.status_code == 200
    assert update_response.json()["name"] == "Jane Smith"
    assert update_response.json()["role"] == Role.COORDINATOR

def test_get_nonexistent_crew():
    response = client.get("/crew/99999")
    assert response.status_code == 404
