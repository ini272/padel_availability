from pydantic import BaseModel, ConfigDict
from datetime import datetime
from typing import List
from app.core.enums import Role, ShiftPlanStatus, PreferenceType

class ShiftAssignmentCreate(BaseModel):
    shift_id: int
    crew_member_id: int

class ShiftAssignment(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    shift_id: int
    crew_member_id: int

class ShiftPreferenceCreate(BaseModel):
    preference_type: PreferenceType
    crew_member_id: int
    shift_id: int

class ShiftPreference(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    preference_type: PreferenceType
    crew_member_id: int
    shift_id: int

class CrewMemberCreate(BaseModel):
    name: str
    role: Role = Role.CREW

class CrewMember(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    role: Role
    assignments: List[ShiftAssignment] = []
    preferences: List[ShiftPreference] = []

class ShiftCreate(BaseModel):
    start_time: datetime
    end_time: datetime
    capacity: int = 1
    shift_plan_id: int

class Shift(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    start_time: datetime
    end_time: datetime
    capacity: int
    shift_plan_id: int
    assignments: List[ShiftAssignment] = []

class ShiftPlanCreate(BaseModel):
    name: str
    status: ShiftPlanStatus = ShiftPlanStatus.DRAFT

class ShiftPlan(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    status: ShiftPlanStatus
    shifts: List[Shift] = []
