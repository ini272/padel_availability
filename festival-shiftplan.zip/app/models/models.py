from sqlalchemy import Column, Integer, String, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime
from app.core.database import Base
from app.core.enums import Role, ShiftPlanStatus, PreferenceType

class ShiftAssignment(Base):
    __tablename__ = "shift_assignments"
    id = Column(Integer, primary_key=True, index=True)
    shift_id = Column(Integer, ForeignKey("shifts.id"))
    crew_member_id = Column(Integer, ForeignKey("crew_members.id"))

    shift = relationship("Shift", back_populates="assignments")
    crew_member = relationship("CrewMember", back_populates="assignments")

class CrewMember(Base):
    __tablename__ = "crew_members"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    role = Column(String, default=Role.CREW)
    
    assignments = relationship("ShiftAssignment", back_populates="crew_member")
    preferences = relationship("ShiftPreference", back_populates="crew_member")

class Shift(Base):
    __tablename__ = "shifts"
    id = Column(Integer, primary_key=True, index=True)
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime, nullable=False)
    capacity = Column(Integer, default=1)
    shift_plan_id = Column(Integer, ForeignKey("shift_plans.id"))

    assignments = relationship("ShiftAssignment", back_populates="shift")
    shift_plan = relationship("ShiftPlan", back_populates="shifts")
    preferences = relationship("ShiftPreference", back_populates="shift")

class ShiftPlan(Base):
    __tablename__ = "shift_plans"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)
    status = Column(String, default=ShiftPlanStatus.DRAFT)
    
    shifts = relationship("Shift", back_populates="shift_plan")

class ShiftPreference(Base):
    __tablename__ = "shift_preferences"
    id = Column(Integer, primary_key=True, index=True)
    preference_type = Column(String)
    crew_member_id = Column(Integer, ForeignKey("crew_members.id"))
    shift_id = Column(Integer, ForeignKey("shifts.id"))

    crew_member = relationship("CrewMember", back_populates="preferences")
    shift = relationship("Shift", back_populates="preferences")
